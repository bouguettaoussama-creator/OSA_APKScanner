import sys
import os
import importlib.util

# الحصول على المسار الحالي للملف المخفي
current_dir = os.path.dirname(os.path.abspath(__file__))
so_path = os.path.join(current_dir, ".sq_core.so")

# تحميل المكتبة المخفية مباشرة
spec = importlib.util.spec_from_file_location("sq_core", so_path)
sq_core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sq_core)

if __name__ == "__main__":
    sq_core.main()
